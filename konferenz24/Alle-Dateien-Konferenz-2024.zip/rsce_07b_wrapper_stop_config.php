<?php
// Wrapper Element für CSS-Grid

return [
	'label' => ['Wrapper Stop-Element für CSS-Grid', ''],
	'types' => ['content'],
	'standardFields' => ['cssID'],
    'contentCategory' => 'Kunde Spezial',
	'wrapper' => [
        'type' => 'stop',
    ],
	'fields' => []
];